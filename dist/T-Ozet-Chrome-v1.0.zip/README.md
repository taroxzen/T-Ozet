﻿# 🤖 Yerel AI Web Özetleyici (Chrome & Firefox Eklentisi)

Haber siteleri, forumlar (DonanımHaber, Ekşi Sözlük, Reddit vb.), bloglar ve seçili metin bloklarını **tamamen yerel yapay zeka** ile tarayıcınızda özetleyin.

---

## 🌟 Öne Çıkan Özellikler

- **🔒 %100 Gizlilik & Çevrimdışı:** Verileriniz internete veya harici sunuculara gitmez; tarayıcınızın kendi donanım gücüyle (WebGPU) çalışır.
- **⚡ On-Demand (Aç-Kapa Güç Düğmesi):** Model arka planda sürekli RAM tüketmez. Sadece açıkken ihtiyaç anında SSD'den yüklenir, kapatıldığında bellek tamamen boşaltılır (0 MB RAM).
- **🇹🇷 Yerli & Güçlü Modeller (Tamamı < 1 GB):**
  1. `🇹🇷 Türkçe Haber Özetleme T5` (~850 MB) - Haber ve 5N1K uzmanı
  2. `🇹🇷 YTÜ Cosmos Turkish T5` (~350 MB) - Yıldız Teknik Üniv. modeli
  3. `🟠 Alibaba Qwen 2.5 (0.5B)` (~350 MB) - Hızlı Türkçe & forum analizi
  4. `📘 Meta Llama 3.2 (1B)` (~700 MB) - Meta çok dilli kompakt model
  5. `💼 IBM Granite 3.0 (1B)` (~680 MB) - Kurumsal doküman analizi
  6. `🍎 Apple OpenELM (450M)` (~320 MB) - Apple ultra hafif model
- **🖱️ İki Pratik Kullanım Şekli:**
  - **Metin Seçimi:** Metni seçip bıraktığınızda beliren mini `🤖 Özetle` butonu.
  - **Sağ Tık:** `🤖 Bu Kısmı Özetle` veya `📄 Tüm Sayfayı Özetle`.
- **🎨 2D Monokrom Avatar Kimliği:** Göz yormayan gri/antrasit sayfa içi özet kartı (Kopyalama, daktilo akışı, format değiştirici).

---

## 🚀 Kurulum (Geliştirici Modunda Yükleme)

### 1. Google Chrome / Brave / Edge için:
1. Tarayıcınızın adres çubuğuna `chrome://extensions` yazın ve Enter'a basın.
2. Sağ üst köşedeki **"Geliştirici modu" (Developer mode)** anahtarını açın.
3. Sol üstte beliren **"Paketlenmemiş öğe yükle" (Load unpacked)** butonuna tıklayın.
4. Bu klasörü (`C:\Users\taner\.gemini\antigravity\scratch\ai-web-summarizer`) seçin.

### 2. Mozilla Firefox için:
1. Adres çubuğuna `about:debugging#/runtime/this-firefox` yazın.
2. **"Geçici Eklenti Yükle..." (Load Temporary Add-on)** butonuna tıklayın.
3. Bu klasördeki `manifest.json` dosyasını seçin.

---

## ⌨️ Kullanım
1. Eklenti simgesine tıklayarak güç anahtarının **AÇIK** olduğundan emin olun.
2. İstediğiniz modeli açılır menüden seçin (Varsayılan: *Türkçe Haber T5*).
3. Herhangi bir haber veya forum sitesinde metin seçin ya da sağ tıklayarak özetleyin!